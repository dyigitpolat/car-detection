# car-detection
Detect and draw bounding boxes of the cars in images using naive heuristics.

Compile with make, run as:

./run image1.png image2.jpg ...
